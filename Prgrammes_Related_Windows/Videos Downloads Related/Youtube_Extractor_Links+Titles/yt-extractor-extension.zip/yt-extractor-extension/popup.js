// popup.js — YT Link Extractor Extension

const INVIDIOUS_INSTANCES = [
  'https://inv.nadeko.net',
  'https://invidious.io.lol',
  'https://yt.cdaut.de'
];
let INVIDIOUS = INVIDIOUS_INSTANCES[0];

// ─────────────────────────────
//  State
// ─────────────────────────────
let selectedDays = 0;
let extractedLinks = [];
let channelName = '';
let outputFilename = '';

// ─────────────────────────────
//  On Load
// ─────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  autoDetectYouTubePage();
  setupFilterButtons();
  setupUrlInputListener();
});

// ─────────────────────────────
//  Auto-detect current YouTube tab
// ─────────────────────────────
function autoDetectYouTubePage() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.url) return;
    const url = tab.url;
    if (!url.includes('youtube.com')) return;

    const parsed = analyzeUrl(url);
    if (!parsed) return;

    const badge = document.getElementById('detectBadge');
    const text  = document.getElementById('detectText');
    badge.classList.add('show');

    const typeLabel = parsed.type === 'shorts' ? 'Shorts'
                    : parsed.type === 'playlist' ? 'Playlist'
                    : 'Channel';
    text.textContent = `✓ تم اكتشاف ${typeLabel} — اضغط لاستخدامها`;

    badge.addEventListener('click', () => {
      document.getElementById('urlInput').value = url;
      updateUrlTypeIndicator(url);
      badge.classList.remove('show');
    });
  });
}

// ─────────────────────────────
//  Filter buttons
// ─────────────────────────────
function setupFilterButtons() {
  document.querySelectorAll('.fbtn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.fbtn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const val = btn.dataset.days;
      selectedDays = val === 'custom' ? 'custom' : parseInt(val);
      document.getElementById('customDateWrap').classList.toggle('show', val === 'custom');
    });
  });
}

// ─────────────────────────────
//  URL type indicator
// ─────────────────────────────
function setupUrlInputListener() {
  document.getElementById('urlInput').addEventListener('input', (e) => {
    updateUrlTypeIndicator(e.target.value);
  });
}

function updateUrlTypeIndicator(url) {
  const el = document.getElementById('urlType');
  if (!url.trim()) { el.className = 'url-type'; return; }
  const p = analyzeUrl(url);
  if (!p) { el.className = 'url-type'; return; }
  const labels = { shorts: '▶ Shorts', playlist: '≡ Playlist', channel: '◉ Channel' };
  el.textContent = labels[p.type] || p.type;
  el.className = `url-type show ${p.type}`;
}

// ─────────────────────────────
//  URL analysis
// ─────────────────────────────
function analyzeUrl(url) {
  const u = (url || '').trim();
  if (!u) return null;
  const plMatch = u.match(/[?&]list=([a-zA-Z0-9_-]+)/);
  if (plMatch) return { type: 'playlist', id: plMatch[1] };
  const handleMatch = u.match(/youtube\.com\/@([^/?#]+)/);
  if (handleMatch) {
    return { type: /\/shorts/.test(u) ? 'shorts' : 'channel', handle: handleMatch[1] };
  }
  const chanMatch = u.match(/youtube\.com\/channel\/([a-zA-Z0-9_-]+)/);
  if (chanMatch) return { type: 'channel', channelId: chanMatch[1] };
  const legacyMatch = u.match(/youtube\.com\/(?:c|user)\/([^/?#]+)/);
  if (legacyMatch) return { type: 'channel', handle: legacyMatch[1] };
  return null;
}

// ─────────────────────────────
//  Logging
// ─────────────────────────────
function log(msg, type = '') {
  const box = document.getElementById('logBox');
  const line = document.createElement('span');
  line.className = `ll ${type}`;
  line.textContent = '> ' + msg;
  box.appendChild(line);
  box.scrollTop = box.scrollHeight;
}

function setStatus(msg) {
  document.getElementById('progStatus').textContent = msg;
}

function showErr(msg) {
  const el = document.getElementById('errBox');
  el.textContent = '⚠ ' + msg;
  el.classList.add('show');
}

function clearErr() {
  document.getElementById('errBox').classList.remove('show');
}

// ─────────────────────────────
//  Date cutoff
// ─────────────────────────────
function getCutoff() {
  if (selectedDays === 0) return null;
  if (selectedDays === 'custom') {
    const val = document.getElementById('customDate').value;
    if (!val) return null;
    return new Date(val).getTime();
  }
  return Date.now() - selectedDays * 86400000;
}

// ─────────────────────────────
//  Invidious fetch with fallback
// ─────────────────────────────
async function invFetch(path) {
  for (const instance of INVIDIOUS_INSTANCES) {
    try {
      const r = await fetch(instance + path);
      if (r.ok) {
        INVIDIOUS = instance;
        return r.json();
      }
    } catch (_) {}
  }
  throw new Error('كل الـ Invidious instances فشلت، حاول تاني لاحقاً');
}

// ─────────────────────────────
//  Helpers
// ─────────────────────────────
function isDeleted(title) {
  if (!title) return true;
  return ['[deleted]','[private]','[unavailable]'].includes(title.toLowerCase());
}

function sanitize(name) {
  return (name || 'output').replace(/[\\/*?:"<>|]/g, '_').trim().replace(/^\.+/, '') || 'output';
}

function fmt(n) {
  if (!n) return '?';
  if (n >= 1e6) return (n/1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n/1e3).toFixed(1) + 'K';
  return String(n);
}

function dedupe(arr) {
  return [...new Set(arr)];
}

function buildFilename(name, type) {
  const ts = new Date().toISOString().slice(0,19).replace(/[-:T]/g, (c) => c==='T' ? '_' : c);
  const suffix = type === 'playlist' ? 'playlist' : type === 'shorts' ? 'shorts' : 'links';
  return `${name}_${suffix}_${ts}.txt`;
}

// ─────────────────────────────
//  API: resolve handle → channelId
// ─────────────────────────────
async function resolveHandle(handle) {
  const data = await invFetch(`/api/v1/search?q=${encodeURIComponent('@' + handle)}&type=channel`);
  if (!data.length) throw new Error('لم يتم إيجاد القناة');
  return { id: data[0].authorId, name: data[0].author };
}

// ─────────────────────────────
//  API: fetch playlist links
// ─────────────────────────────
async function fetchPlaylist(playlistId, cutoff) {
  const links = [];
  let page = 1;
  while (true) {
    setStatus(`صفحة ${page}...`);
    const data = await invFetch(`/api/v1/playlists/${playlistId}?page=${page}`);
    if (page === 1) {
      log(`القائمة: ${data.title}`, 'inf');
      log(`إجمالي: ${data.videoCount} فيديو`, 'inf');
      channelName = sanitize(data.title);
    }
    const videos = data.videos || [];
    if (!videos.length) break;
    let done = false;
    for (const v of videos) {
      if (!v.videoId || isDeleted(v.title)) continue;
      if (cutoff && v.published && v.published * 1000 < cutoff) { done = true; break; }
      links.push(`https://www.youtube.com/watch?v=${v.videoId}`);
    }
    log(`صفحة ${page}: +${videos.length} (مجموع: ${links.length})`, 'ok');
    if (done || videos.length < 100) break;
    page++;
  }
  return links;
}

// ─────────────────────────────
//  API: fetch channel/shorts links
// ─────────────────────────────
async function fetchChannel(channelId, type, cutoff) {
  const links = [];
  const info = await invFetch(`/api/v1/channels/${channelId}`);
  channelName = sanitize(info.author || channelId);
  log(`القناة: ${info.author}`, 'inf');
  log(`المشتركون: ${fmt(info.subCount)}`, 'inf');

  const endpoint = type === 'shorts'
    ? `/api/v1/channels/${channelId}/shorts`
    : `/api/v1/channels/${channelId}/videos`;

  let continuation = null;
  let page = 1;

  while (true) {
    setStatus(`صفحة ${page}...`);
    const params = continuation ? `?continuation=${continuation}` : '';
    const data = await invFetch(`${endpoint}${params}`);
    const videos = data.videos || [];
    if (!videos.length) break;

    let done = false;
    for (const v of videos) {
      if (!v.videoId || isDeleted(v.title)) continue;
      if (cutoff && v.published && v.published * 1000 < cutoff) { done = true; break; }
      links.push(`https://www.youtube.com/watch?v=${v.videoId}`);
    }
    log(`صفحة ${page}: +${videos.length} (مجموع: ${links.length})`, 'ok');
    if (done || !data.continuation) break;
    continuation = data.continuation;
    page++;
  }
  return links;
}

// ─────────────────────────────
//  Main extract
// ─────────────────────────────
async function startExtract() {
  clearErr();
  extractedLinks = [];
  channelName = '';

  const url = document.getElementById('urlInput').value.trim();
  if (!url) { showErr('أدخل رابط القناة أولاً'); return; }

  const parsed = analyzeUrl(url);
  if (!parsed) { showErr('الرابط غير صحيح أو غير مدعوم'); return; }

  // Reset UI
  document.getElementById('logBox').innerHTML = '';
  document.getElementById('resultsArea').classList.remove('show');
  document.getElementById('progressArea').classList.add('show');
  document.getElementById('goBtn').disabled = true;

  const bar = document.getElementById('progBar');
  bar.classList.add('ind');

  const cutoff = getCutoff();
  if (cutoff) log(`فلتر: منذ ${new Date(cutoff).toLocaleDateString('ar')}`, 'inf');

  try {
    let links = [];

    if (parsed.type === 'playlist') {
      log(`نوع: Playlist — ${parsed.id}`, 'inf');
      links = await fetchPlaylist(parsed.id, cutoff);

    } else {
      let channelId = parsed.channelId;
      if (!channelId && parsed.handle) {
        log(`تحليل @${parsed.handle}...`, 'inf');
        setStatus('تحليل القناة...');
        const resolved = await resolveHandle(parsed.handle);
        channelId = resolved.id;
        channelName = sanitize(resolved.name);
        log(`تم إيجاد: ${resolved.name}`, 'ok');
      }
      log(`نوع: ${parsed.type === 'shorts' ? 'Shorts' : 'Channel Videos'}`, 'inf');
      links = await fetchChannel(channelId, parsed.type, cutoff);
    }

    // Deduplicate
    const before = links.length;
    links = dedupe(links);
    const dupsRemoved = before - links.length;
    if (dupsRemoved > 0) log(`مكرر مُزال: ${dupsRemoved}`, 'inf');

    extractedLinks = links;

    if (!links.length) throw new Error('لا توجد فيديوهات بعد الفلترة');

    log(`✅ اكتمل — ${links.length} لينك`, 'ok');
    setStatus('✅ اكتمل!');
    bar.classList.remove('ind');
    bar.style.width = '100%';

    showResults(parsed.type, dupsRemoved);

  } catch (err) {
    log('❌ ' + err.message, 'err');
    setStatus('❌ خطأ');
    bar.classList.remove('ind');
    bar.style.background = 'var(--accent)';
    showErr(err.message);
  } finally {
    document.getElementById('goBtn').disabled = false;
  }
}

// ─────────────────────────────
//  Show results
// ─────────────────────────────
function showResults(type, dupsRemoved) {
  document.getElementById('resultsArea').classList.add('show');

  document.getElementById('statsRow').innerHTML = `
    <div class="stat"><span class="stat-n">${extractedLinks.length}</span><span class="stat-l">لينك</span></div>
    <div class="stat"><span class="stat-n" style="color:var(--accent2)">${dupsRemoved}</span><span class="stat-l">مكرر مُزال</span></div>
    <div class="stat"><span class="stat-n" style="color:#aaa;font-size:.85rem">${type==='shorts'?'Shorts':type==='playlist'?'Playlist':'Channel'}</span><span class="stat-l">النوع</span></div>
  `;

  const prev = document.getElementById('preview');
  prev.innerHTML = extractedLinks.slice(0, 30).join('\n');
  if (extractedLinks.length > 30) prev.innerHTML += `\n... و ${extractedLinks.length - 30} آخر`;

  outputFilename = buildFilename(channelName || 'output', type);

  document.getElementById('dlBtn').onclick = downloadFile;
  document.getElementById('hint').innerHTML =
    `// لتنزيل الكل:<br><span>yt-dlp -a "${outputFilename}"</span>`;
}

// ─────────────────────────────
//  Download via chrome.downloads
// ─────────────────────────────
function downloadFile() {
  const content = extractedLinks.join('\n') + '\n';
  const dataUrl = 'data:text/plain;charset=utf-8,' + encodeURIComponent(content);
  chrome.downloads.download({
    url: dataUrl,
    filename: outputFilename,
    saveAs: false
  });
}
