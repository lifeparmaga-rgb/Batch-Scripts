// background.js — service worker
// مش محتاج منطق كتير، الـ popup بيعمل كل حاجة
chrome.runtime.onInstalled.addListener(() => {
  console.log('YT Link Extractor installed');
});
