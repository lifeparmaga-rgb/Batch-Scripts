// content.js — يشتغل على صفحات يوتيوب
// بيكتشف الـ URL الحالية ويبعتها للـ popup لما يطلبها

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_CURRENT_URL') {
    sendResponse({ url: window.location.href });
  }
});
